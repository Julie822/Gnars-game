/**
 * 
 */
/**
 * @author Julie
 *
 */
module Trex {
	requires java.desktop;
}